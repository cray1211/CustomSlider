//
//  ViewController.m
//  CustomProgress
//
//  Created by mac on 2021/1/22.
//

#import "ViewController.h"
#import "Masonry.h"
#import "CustomSliderView.h"
#import "UIColor+Extension.h"

#define VIEW_WIDTH [UIScreen mainScreen].bounds.size.width
#define ScaleW(width)  width*VIEW_WIDTH/375
#define systemFont(x) [UIFont systemFontOfSize:x]
@interface ViewController ()
@property (nonatomic ,strong) CustomSliderView *slider;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = UIColor.whiteColor;
    
    [self.view addSubview:self.slider];
    
    
    self.slider.hideTopIndex = YES;
    self.slider.currentIndex = 0;
    self.slider.baifenbiArr = @[@"100", @"200",@"500", @"1000", @"2000"];
    
    
    
    
    [self.slider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.view).offset(20);
        make.right.mas_equalTo(self.view).offset(-20);
        make.centerY.mas_equalTo(self.view.mas_centerY);
        make.height.mas_equalTo(ScaleW(60));
    }];
}




- (CustomSliderView *)slider{
    if (!_slider) {
        
        _slider = [[CustomSliderView alloc] init];
        _slider.selectedBgColor = UIColor.orangeColor;
        _slider.normalBgColor = [UIColor colorWithHexString:@"#f5f5f5"];
        _slider.currentCycleColor = UIColor.orangeColor;
        _slider.selectedCycleColor = UIColor.orangeColor;
        _slider.currentCycleBoardColor = [UIColor colorWithHexString:@"#E65E44"];
        _slider.selectedIndexCallback = ^(NSInteger index, NSString *valueStr) {
            NSLog(@"%ld----%@", index, valueStr);
        };
    }
    return _slider;
}



@end
