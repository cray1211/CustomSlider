//
//  ViewController.h
//  CustomProgress
//
//  Created by mac on 2021/1/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

